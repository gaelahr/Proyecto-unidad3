import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart'; 
import 'package:http/http.dart' as http; 
import 'dart:convert';
import 'package:intl/intl.dart'; 
import 'package:google_maps_flutter/google_maps_flutter.dart'; 
import 'package:image_picker/image_picker.dart'; 
import 'dart:typed_data'; 
import 'dart:io'; 
import 'package:crypto/crypto.dart';
import 'dart:convert'; // Necesario para utf8

void main() => runApp(const MyApp());

// Datos globales de la sesión simulada (reemplazo del token JWT)
class SessionData {
  static int userId = 0;
  static int roleId = 0; // 1: Admin, 3: Delivery Agent
  static String fullName = "";
  static String token = ""; // Token simulado
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Sistema Unificado',
      theme: ThemeData(
        primaryColor: const Color(0xFF0D47A1), 
        scaffoldBackgroundColor: const Color(0xFFE3F2FD), 
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1565C0), 
          foregroundColor: Colors.white,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF0D47A1), 
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            textStyle: const TextStyle(fontSize: 18),
          ),
        ),
        cardColor: Colors.white,
      ),
      home: const LoginPage(),
    );
  }
}

// --- PANTALLA DE LOGIN ---
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final TextEditingController _usernameController = TextEditingController(text: "agent"); // Valor por defecto
  final TextEditingController _passwordController = TextEditingController(text: "agentpass"); // Valor por defecto
  final String apiBaseUrl = "http://localhost:8000";
  bool _isLoading = false;

  Future<void> _login() async {
    setState(() => _isLoading = true);
    final url = Uri.parse("$apiBaseUrl/login/");
    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: json.encode({
          "username": _usernameController.text,
          "password": _passwordController.text,
        }),
      );

      final decoded = utf8.decode(response.bodyBytes);
      final data = json.decode(decoded);

      if (response.statusCode == 200) {
        SessionData.userId = data['user_id'];
        SessionData.roleId = data['role_id'];
        SessionData.fullName = data['full_name'];
        SessionData.token = data['access_token'];

        // Navegación basada en el rol
        if (SessionData.roleId == 1) { // Admin
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const AdminDashboard()));
        } else if (SessionData.roleId == 3) { // Delivery Agent
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const DeliveryDashboard()));
        } else {
          _showError("Rol no soportado: ${SessionData.roleId}");
        }
      } else {
        _showError(data['detail'] ?? "Credenciales incorrectas");
      }
    } catch (e) {
      _showError("Error de conexión: $e");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Inicio de Sesión")),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text("Sistema Unificado de Agentes", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 30),
              TextField(
                controller: _usernameController,
                decoration: const InputDecoration(labelText: "Usuario", border: OutlineInputBorder()),
              ),
              const SizedBox(height: 15),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: const InputDecoration(labelText: "Contraseña", border: OutlineInputBorder()),
              ),
              const SizedBox(height: 30),
              _isLoading
                  ? const CircularProgressIndicator()
                  : ElevatedButton.icon(
                      onPressed: _login,
                      icon: const Icon(Icons.lock_open),
                      label: const Text("Entrar al Sistema"),
                      style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}

// --- PANTALLA DE DASHBOARD PARA AGENTES ---
class DeliveryDashboard extends StatefulWidget {
  const DeliveryDashboard({super.key});
  @override
  State<DeliveryDashboard> createState() => _DeliveryDashboardState();
}
class _DeliveryDashboardState extends State<DeliveryDashboard> {
  int _selectedIndex = 0;

  static final List<Widget> _widgetOptions = <Widget>[
    const DeliveryScreen(), // Entrega de Paquetes
    const AttendanceScreen(), // Asistencia/Mapa
    const GalleryScreen(), // Galería/Fotos
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Agente: ${SessionData.fullName}"),
        automaticallyImplyLeading: false, // Deshabilita el back button
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              // Limpiar sesión y navegar a login
              SessionData.userId = 0;
              SessionData.roleId = 0;
              Navigator.pushAndRemoveUntil(
                context, 
                MaterialPageRoute(builder: (context) => const LoginPage()), 
                (Route<dynamic> route) => false,
              );
            },
          )
        ],
      ),
      body: Center(child: _widgetOptions.elementAt(_selectedIndex)),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.local_shipping), label: 'Entregas'),
          BottomNavigationBarItem(icon: Icon(Icons.location_on), label: 'Asistencia'),
          BottomNavigationBarItem(icon: Icon(Icons.camera_alt), label: 'Galería'),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Theme.of(context).primaryColor,
        onTap: _onItemTapped,
      ),
    );
  }
}

// --- 1. Sub Pantalla: GESTIÓN DE ENTREGAS ---
class DeliveryScreen extends StatefulWidget {
  const DeliveryScreen({super.key});
  @override
  State<DeliveryScreen> createState() => _DeliveryScreenState();
}
class _DeliveryScreenState extends State<DeliveryScreen> {
  Future<List<dynamic>>? _packagesFuture;
  final String apiBaseUrl = "http://localhost:8000";

  @override
  void initState() {
    super.initState();
    _packagesFuture = fetchAssignedPackages();
  }

  Future<List<dynamic>> fetchAssignedPackages() async {
    final response = await http.get(
      Uri.parse("$apiBaseUrl/packages/assigned/${SessionData.userId}"),
      headers: {"Content-Type": "application/json"},
    );
    if (response.statusCode == 200) {
      final decoded = utf8.decode(response.bodyBytes);
      return json.decode(decoded);
    } else {
      final decodedError = utf8.decode(response.bodyBytes);
      final errorData = json.decode(decodedError);
      throw Exception('Fallo al cargar paquetes: ${errorData['detail']}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<dynamic>>(
      future: _packagesFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(child: Padding(padding: const EdgeInsets.all(20), child: Text("Error: ${snapshot.error}", textAlign: TextAlign.center)));
        } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return const Center(child: Text("No tienes paquetes asignados pendientes."));
        } else {
          return ListView.builder(
            padding: const EdgeInsets.all(8),
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              var package = snapshot.data![index];
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  leading: const Icon(Icons.archive, color: Colors.orange),
                  title: Text("Paquete ID: ${package['package_id']}"),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Dirección: ${package['address']}", style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text("Desc: ${package['description'] ?? 'N/A'}"),
                    ],
                  ),
                  trailing: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => DeliveryRecordPage(packageData: package),
                        ),
                      ).then((_) {
                        // Recargar la lista al regresar
                        setState(() {
                          _packagesFuture = fetchAssignedPackages();
                        });
                      });
                    },
                    child: const Text("Entregar"),
                  ),
                ),
              );
            },
          );
        }
      },
    );
  }
}

// --- PANTALLA PARA REGISTRAR ENTREGA (FOTO Y GEOLOCALIZACIÓN) ---
class DeliveryRecordPage extends StatefulWidget {
  final Map<String, dynamic> packageData;
  const DeliveryRecordPage({super.key, required this.packageData});
  @override
  State<DeliveryRecordPage> createState() => _DeliveryRecordPageState();
}
class _DeliveryRecordPageState extends State<DeliveryRecordPage> {
  XFile? _pickedFile;
  Uint8List? _imageBytes;
  bool _isLoading = false;
  final picker = ImagePicker();
  final String apiBaseUrl = "http://localhost:8000";

  Future<void> _getImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.camera);
    if (pickedFile != null) {
      final bytes = await pickedFile.readAsBytes();
      setState(() {
        _imageBytes = bytes;
        _pickedFile = pickedFile;
      });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Foto de prueba de entrega tomada ✅")));
    }
  }

  Future<void> _recordDelivery() async {
    if (_pickedFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Debe tomar una foto de prueba de entrega 📸")));
      return;
    }
    setState(() => _isLoading = true);

    try {
      Position pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);

      var request = http.MultipartRequest(
        'POST', 
        Uri.parse('$apiBaseUrl/deliveries/record/'), 
      );

      // Campos de texto (Metadata)
      request.fields['package_id'] = widget.packageData['package_id'].toString();
      request.fields['delivered_by_user_id'] = SessionData.userId.toString();
      request.fields['delivery_latitude'] = pos.latitude.toString();
      request.fields['delivery_longitude'] = pos.longitude.toString();

      // Archivo (La Foto)
      request.files.add(
        http.MultipartFile.fromBytes(
          'file', 
          _imageBytes!, 
          filename: _pickedFile!.name,
        ),
      );

      var response = await request.send();
      var respStr = await response.stream.bytesToString();

      if (response.statusCode == 200) {
        var data = json.decode(respStr);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Entrega registrada con éxito: ${data['address']} ✅"), backgroundColor: Colors.green),
        );
        Navigator.pop(context); // Regresa al dashboard de entregas
      } else {
        var data = json.decode(respStr);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error al registrar entrega: ${data['detail'] ?? 'Error desconocido'} ❌"), backgroundColor: Colors.red),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error al registrar: $e ❌"), backgroundColor: Colors.red),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Registrar Entrega #${widget.packageData['package_id']}")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: ListTile(
                title: Text(widget.packageData['address'], style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(widget.packageData['description'] ?? 'Sin descripción'),
              ),
            ),
            const SizedBox(height: 20),
            Center(
              child: _imageBytes == null
                  ? const Text("No hay foto de prueba de entrega seleccionada")
                  : Image.memory(_imageBytes!, height: 200, fit: BoxFit.cover),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              icon: const Icon(Icons.camera_alt),
              label: const Text("Tomar Foto de Entrega"),
              onPressed: _getImage,
            ),
            const SizedBox(height: 15),
            _isLoading
                ? const Center(child: CircularProgressIndicator())
                : ElevatedButton.icon(
                    icon: const Icon(Icons.check_circle),
                    label: const Text("Paquete Entregado y Guardado"),
                    onPressed: _recordDelivery,
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.green.shade700),
                  ),
          ],
        ),
      ),
    );
  }
}


// --- 2. Sub Pantalla: REGISTRO DE ASISTENCIA ---
class AttendanceScreen extends StatefulWidget {
  const AttendanceScreen({super.key});
  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}
class _AttendanceScreenState extends State<AttendanceScreen> {
  String result = "Presiona el botón para registrar tu ubicación.";
  bool isLoading = false;
  final String apiBaseUrl = "http://localhost:8000"; 
  
  Future<void> registerAttendance() async {
    setState(() => isLoading = true);
    result = "";
    try {
      Position pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      var url = Uri.parse("$apiBaseUrl/attendance/"); 
      var response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: json.encode({
          "user_id": SessionData.userId,
          "latitude": pos.latitude,
          "longitude": pos.longitude,
        }),
      );
      var decoded = utf8.decode(response.bodyBytes);
      var data = json.decode(decoded);
      if (response.statusCode == 200) {
        setState(() {
          result = "Registro Exitoso:\n📍 ${data['address']}";
        });
        
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => MapDisplayPage(
              latitude: double.parse(data['latitude'].toString()), 
              longitude: double.parse(data['longitude'].toString()),
              address: data['address'],
            ),
          ),
        );
      } else {
        setState(() {
          result = "❌ Error ${response.statusCode}: ${data['detail']}";
        });
      }
    } catch (e) {
      setState(() {
        result = "❌ Error al registrar asistencia: $e";
      });
    } finally {
      setState(() => isLoading = false);
    }
  }
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Agente: ${SessionData.fullName} (ID ${SessionData.userId})",
              style: const TextStyle(fontSize: 14, color: Colors.blueGrey),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              icon: const Icon(Icons.location_on),
              label: const Text("Registrar Asistencia"),
              onPressed: isLoading ? null : registerAttendance,
            ),
            const SizedBox(height: 30),
            isLoading
                ? const CircularProgressIndicator()
                : Card(
                    elevation: 5,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(
                        result,
                        style: const TextStyle(fontSize: 16),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  )
          ],
        ),
      ),
    );
  }
}

// --- 3. Sub Pantalla: GALERÍA DE FOTOS ---
class GalleryScreen extends StatefulWidget {
  const GalleryScreen({super.key});
  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}
class _GalleryScreenState extends State<GalleryScreen> {
  Uint8List? _imageBytes;
  XFile? _pickedFile;
  final picker = ImagePicker();
  final descripcionController = TextEditingController();
  final String apiBaseUrl = "http://localhost:8000";

  Future _getImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.camera);
    if (pickedFile != null) {
      final bytes = await pickedFile.readAsBytes();
      setState(() {
        _imageBytes = bytes;
        _pickedFile = pickedFile;
      });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Foto tomada correctamente ✅")));
    }
  }

  Future _subirFoto() async {
    if (_pickedFile == null || _imageBytes == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Primero toma una foto ❗")));
      return;
    }

    var request = http.MultipartRequest(
      'POST', 
      Uri.parse('$apiBaseUrl/fotos/'), 
    );

    request.fields['descripcion'] = descripcionController.text;
    request.fields['user_id'] = SessionData.userId.toString(); // Enviamos el ID del usuario
    request.files.add(
      http.MultipartFile.fromBytes(
        'file', 
        _imageBytes!, 
        filename: _pickedFile!.name, 
      ),
    );

    var response = await request.send();
    var respStr = await response.stream.bytesToString();

    if (response.statusCode == 200) {
      setState(() {
        _imageBytes = null;
        _pickedFile = null;
        descripcionController.clear();
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Foto subida correctamente ✅"), backgroundColor: Colors.green),
      );
    } else {
      print("Error al subir foto: ${response.statusCode}");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Error al subir la foto ❌"), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Expanded(
            child: Center(
              child: _imageBytes == null
                  ? const Text("No hay imagen seleccionada")
                  : Image.memory(_imageBytes!, width: 300, fit: BoxFit.cover),
            ),
          ),
          TextField(
            controller: descripcionController,
            decoration: const InputDecoration(labelText: "Descripción de la foto", border: OutlineInputBorder()),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Expanded(child: ElevatedButton.icon(onPressed: _getImage, icon: const Icon(Icons.camera), label: const Text("Tomar Foto"))),
              const SizedBox(width: 10),
              Expanded(child: ElevatedButton.icon(onPressed: _subirFoto, icon: const Icon(Icons.upload), label: const Text("Subir a API"))),
            ],
          ),
        ],
      ),
    );
  }
}


// --- PANTALLA DE ADMIN (Solo Historial) ---
class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Admin: ${SessionData.fullName}"),
        automaticallyImplyLeading: false,
        actions: [
           IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              SessionData.userId = 0;
              SessionData.roleId = 0;
              Navigator.pushAndRemoveUntil(
                context, 
                MaterialPageRoute(builder: (context) => const LoginPage()), 
                (Route<dynamic> route) => false,
              );
            },
          )
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("Bienvenido, Administrador.", style: TextStyle(fontSize: 20)),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              icon: const Icon(Icons.history),
              label: const Text("Ver Historial de Asistencias"),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const AttendanceHistoryPage(),
                  ),
                );
              },
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              icon: const Icon(Icons.photo_library),
              label: const Text("Ver Galería de Fotos"),
              onPressed: () {
                 Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const FullGalleryPage(),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

// --- PANTALLA DE MAPA INTERACTIVO (Compartida) ---
class MapDisplayPage extends StatelessWidget {
  final double latitude;
  final double longitude;
  final String address;
  const MapDisplayPage({
    super.key,
    required this.latitude,
    required this.longitude,
    required this.address,
  });
  @override
  Widget build(BuildContext context) {
    final LatLng position = LatLng(latitude, longitude);
    return Scaffold(
      appBar: AppBar(title: const Text("Ubicación Registrada")),
      body: Column(
        children: [
          Expanded(
            child: GoogleMap(
              initialCameraPosition: CameraPosition(
                target: position,
                zoom: 16,
              ),
              markers: {
                Marker(
                  markerId: const MarkerId("location"),
                  position: position,
                  infoWindow: InfoWindow(title: "Ubicación", snippet: address),
                ),
              },
              myLocationEnabled: true,
              compassEnabled: true,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              "Dirección: $address",
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}

// --- PANTALLA DE HISTORIAL DE ASISTENCIA (Solo Admin) ---
class AttendanceHistoryPage extends StatefulWidget {
  const AttendanceHistoryPage({super.key});
  @override
  State<AttendanceHistoryPage> createState() => _AttendanceHistoryPageState();
}
class _AttendanceHistoryPageState extends State<AttendanceHistoryPage> {
  Future<List<dynamic>>? _historyFuture;
  final String apiBaseUrl = "http://localhost:8000"; 
  @override
  void initState() {
    super.initState();
    _historyFuture = fetchAttendanceHistory();
  }
  Future<List<dynamic>> fetchAttendanceHistory() async {
    final response = await http.post(
      Uri.parse("$apiBaseUrl/attendance/history/"),
      headers: {"Content-Type": "application/json"},
      body: json.encode({"user_id": SessionData.userId}),
    );
    if (response.statusCode == 200) {
      var decoded = utf8.decode(response.bodyBytes);
      return json.decode(decoded);
    } else {
      var decodedError = utf8.decode(response.bodyBytes);
      var errorData = json.decode(decodedError);
      throw Exception('Fallo al cargar el historial: ${errorData['detail']}');
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Historial de Asistencias (Admin)")),
      body: FutureBuilder<List<dynamic>>(
        future: _historyFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Text("Error: ${snapshot.error}", textAlign: TextAlign.center),
            ));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("No hay registros de asistencia."));
          } else {
            return ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                var record = snapshot.data![index];
                DateTime registeredAt = DateTime.parse(record['registered_at']);
                String formattedDate = DateFormat('dd/MM/yyyy HH:mm:ss').format(registeredAt);
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    leading: const Icon(Icons.check_circle, color: Color(0xFF0D47A1)),
                    title: Text("Reg. ID: ${record['attendance_id']} - User ID: ${record['user_id']}"),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(formattedDate, style: const TextStyle(fontStyle: FontStyle.italic)),
                        Text(record['address'], style: const TextStyle(fontWeight: FontWeight.bold)),
                        Text("Lat: ${record['latitude']}, Lon: ${record['longitude']}"),
                      ],
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.map, color: Colors.green),
                      onPressed: () {
                         Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => MapDisplayPage(
                                latitude: double.parse(record['latitude'].toString()),
                                longitude: double.parse(record['longitude'].toString()),
                                address: record['address'],
                              ),
                            ),
                          );
                      },
                    ),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}

// --- PANTALLA DE GALERÍA COMPLETA (Solo Admin) ---
class FullGalleryPage extends StatefulWidget {
  const FullGalleryPage({super.key});
  @override
  State<FullGalleryPage> createState() => _FullGalleryPageState();
}
class _FullGalleryPageState extends State<FullGalleryPage> {
  Future<List<dynamic>>? _galleryFuture;
  final String apiBaseUrl = "http://localhost:8000"; 
  @override
  void initState() {
    super.initState();
    _galleryFuture = fetchGallery();
  }
  Future<List<dynamic>> fetchGallery() async {
    final response = await http.get(Uri.parse("$apiBaseUrl/fotos/"));
    if (response.statusCode == 200) {
      final decoded = utf8.decode(response.bodyBytes);
      return json.decode(decoded);
    } else {
      throw Exception('Fallo al cargar la galería');
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Galería Completa (Admin)")),
      body: FutureBuilder<List<dynamic>>(
        future: _galleryFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Padding(padding: const EdgeInsets.all(20.0), child: Text("Error: ${snapshot.error}", textAlign: TextAlign.center)));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("No hay fotos en la galería."));
          } else {
            return GridView.builder(
              padding: const EdgeInsets.all(8),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
              ),
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                var photo = snapshot.data![index];
                return GridTile(
                  footer: GridTileBar(
                    backgroundColor: Colors.black54,
                    title: Text("ID ${photo['id']}"),
                    subtitle: Text(photo['descripcion']),
                  ),
                  child: Image.network(
                    "$apiBaseUrl/${photo['ruta_foto']}",
                    fit: BoxFit.cover,
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}